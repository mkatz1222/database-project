from sqlalchemy import text, DDL, event
from sqlalchemy.sql.expression import func

from RealestateSite import db
from RealestateSite.models import Houses, Agents, Branches


def nextHighestID():
    maxHouseID = db.session.query(func.max(Houses.houseID))
    maxID = maxHouseID[0]
    maxID = maxID[0]
    nextMaxID = maxID+1
    return nextMaxID


def selectAllUsers():
    value = text("SELECT * FROM agents")
    return value


def selectAllBranches():
    branches = db.session.query(Branches).all()
    for x in branches:
        print(x)

def compareBranchesFunction(branchOne, branchTwo):
    firstBranch = Branches.query.filter(Branches.branchID == branchOne).all()
    secondBranch = Branches.query.filter(Branches.branchID == branchTwo).all()
    x = firstBranch[0]
    y = secondBranch[0]
    if x.averageIncome > y.averageIncome:
        return [x,y]
    else:
        return [y,x]


# The below code was supposed to create a trigger to update a branch's average income but has so far failed to do so
# for unknown reasons.

# trigger = DDL('''\
# drop trigger IF EXISTS update_avg_income1;
# CREATE TRIGGER update_avg_income1 AFTER UPDATE ON agents
#
#     FOR EACH ROW
#     BEGIN
#         select AverageIncome into @avg_inc from (select agents.branchID, avg(incomeLastYear) as 'AverageIncome' from agents, branches where agents.branchID=branches.branchID group by agents.branchID) as temp where branchID = NEW.branchID;
#         UPDATE branches
#         SET avg_income = @avg_inc
#         WHERE branchID = NEW.branchID;
#     END;''')
# event.listen(Agents.__tablename__, 'after_insert', update_task_state)
